def handler(event, context):
    return {"statusCode": 200, "body": "Hello from D3-S6"}
